/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-B24
 */

#include <xdc/std.h>

#include <ti/sysbios/knl/Task.h>
extern const ti_sysbios_knl_Task_Handle task0;

#include <ti/sysbios/family/arm/m3/Hwi.h>
extern const ti_sysbios_family_arm_m3_Hwi_Handle ADC_ISR_Handle;

#include <ti/sysbios/knl/Clock.h>
extern const ti_sysbios_knl_Clock_Handle btnClockHandle;

#include <ti/sysbios/knl/Task.h>
extern const ti_sysbios_knl_Task_Handle ButtonScanHandle;

#include <ti/sysbios/knl/Semaphore.h>
extern const ti_sysbios_knl_Semaphore_Handle btnSem;

#include <ti/sysbios/knl/Mailbox.h>
extern const ti_sysbios_knl_Mailbox_Handle btnMailbox;

#include <ti/sysbios/gates/GateMutex.h>
extern const ti_sysbios_gates_GateMutex_Handle settingGate;

#include <ti/sysbios/knl/Task.h>
extern const ti_sysbios_knl_Task_Handle settingUpdateHandle;

#include <ti/sysbios/knl/Semaphore.h>
extern const ti_sysbios_knl_Semaphore_Handle triggerFindSem;

#include <ti/sysbios/knl/Task.h>
extern const ti_sysbios_knl_Task_Handle triggerFindHandle;

#include <ti/sysbios/knl/Task.h>
extern const ti_sysbios_knl_Task_Handle ProcessingHandle;

#include <ti/sysbios/knl/Task.h>
extern const ti_sysbios_knl_Task_Handle DisplayHandle;

#include <ti/sysbios/knl/Semaphore.h>
extern const ti_sysbios_knl_Semaphore_Handle processingSem;

#include <ti/sysbios/knl/Semaphore.h>
extern const ti_sysbios_knl_Semaphore_Handle displaySem;

#include <ti/sysbios/gates/GateHwi.h>
extern const ti_sysbios_gates_GateHwi_Handle gateHwi0;

#include <ti/sysbios/family/arm/m3/Hwi.h>
extern const ti_sysbios_family_arm_m3_Hwi_Handle captureHwi;

#include <ti/sysbios/knl/Clock.h>
extern const ti_sysbios_knl_Clock_Handle periodClock;

#include <ti/sysbios/knl/Semaphore.h>
extern const ti_sysbios_knl_Semaphore_Handle freqSem;

#include <ti/sysbios/gates/GateHwi.h>
extern const ti_sysbios_gates_GateHwi_Handle gateHwi1;

#include <ti/sysbios/knl/Task.h>
extern const ti_sysbios_knl_Task_Handle FrequencyHandle;

extern int xdc_runtime_Startup__EXECFXN__C;

extern int xdc_runtime_Startup__RESETFXN__C;

